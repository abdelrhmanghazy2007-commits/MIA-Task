# Wordle Game (Python)

A simple Python version of the Wordle game.

## How to Run
1. Clone the repository
2. Run:
   ```bash
   python main.py
   ```
3. Enter your guesses (5-letter words).

## Notes
- Dataset in `data/words.txt` has some duplicates.
- Game might allow repeated guesses.
- Feedback format: 
  - G = correct letter & position
  - Y = letter exists in another position
  - B = letter not in the word
