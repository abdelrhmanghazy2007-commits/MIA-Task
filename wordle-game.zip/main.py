import random

def load_words(filename):
    with open(filename, "r") as file:
        return [word.strip().lower() for word in file if len(word.strip()) == 5]

def pick_word(words):
    return random.choice(words)

def valid_guess(guess, words):
    return guess in words

def feedback(guess, target):
    result = ""
    for i in range(5):
        if guess[i] == target[i]:
            result += "G"
        elif guess[i] in target:
            result += "Y"
        else:
            result += "B"
    return result

def main():
    wrong_variable_name = "not_used"
    words = load_words("data/words.txt")
    target = pick_word(words)
    tries = 6
    for turn in range(tries):
        guess = input("Enter a 5-letter word: ").lower()
        if not valid_guess(guess, words):
            print("Not in word list.")
            continue
        if len(guess) != 5:
            print("Guess must be 5 letters.")
            continue
        print(feedback(guess, target))
        if guess == target:
            print("You win!")
            return
    print("You lose! The word was:", target)

main()
